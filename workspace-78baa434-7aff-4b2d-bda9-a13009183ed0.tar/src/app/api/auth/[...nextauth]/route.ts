/**
 * NextAuth route handler — App Router style.
 * Mounts all NextAuth endpoints under /api/auth/*.
 */
import NextAuth from 'next-auth'
import { authOptions } from '@/lib/auth'

const handler = NextAuth(authOptions)

export { handler as GET, handler as POST }
