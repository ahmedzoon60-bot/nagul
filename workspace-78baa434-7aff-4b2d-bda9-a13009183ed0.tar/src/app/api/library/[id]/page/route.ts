/**
 * Page reader for a source.
 * GET /api/library/[id]/page?page=N
 *
 * Returns the page text + chunk previews for that page, plus pageCount for navigation.
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { logMissingSource } from '@/lib/rag/log'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await ctx.params
    if (!id || id.length < 5) {
      logMissingSource({ route: '/api/library/[id]/page', sourceId: id, reason: 'invalid_id' })
      return NextResponse.json({ error: 'معرف المصدر غير صالح.' }, { status: 400 })
    }
    const source = await db.source.findUnique({
      where: { id },
      select: { id: true, pageCount: true, status: true },
    })
    if (!source) {
      logMissingSource({ route: '/api/library/[id]/page', sourceId: id })
      return NextResponse.json({ error: 'المصدر غير موجود.' }, { status: 404 })
    }

    const url = new URL(req.url)
    const pageStr = url.searchParams.get('page') || '1'
    const page = parseInt(pageStr, 10)
    if (!Number.isFinite(page) || page < 1) {
      return NextResponse.json(
        { error: 'رقم الصفحة غير صالح.' },
        { status: 400 }
      )
    }

    // We don't keep raw page text as a separate column; reconstruct from chunks
    const chunks = await db.chunk.findMany({
      where: { sourceId: id, pageNumber: page },
      orderBy: { chunkIndex: 'asc' },
      select: {
        id: true,
        chunkIndex: true,
        originalText: true,
        startOffset: true,
        endOffset: true,
      },
    })

    const text = chunks.map((c) => c.originalText).join('\n\n')

    return NextResponse.json({
      pageNumber: page,
      pageCount: source.pageCount,
      text,
      chunks: chunks.map((c) => ({
        id: c.id,
        chunkIndex: c.chunkIndex,
        text: c.originalText.slice(0, 400),
        startOffset: c.startOffset,
      })),
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر جلب الصفحة.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
