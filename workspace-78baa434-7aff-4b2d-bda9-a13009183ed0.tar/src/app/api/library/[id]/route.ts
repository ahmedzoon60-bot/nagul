/**
 * Library [id] API
 * GET    /api/library/[id]   -> source detail + sample chunks
 * DELETE /api/library/[id]   -> delete source + chunks + PDF file
 */
import { NextResponse } from 'next/server'
import fs from 'fs/promises'
import path from 'path'
import { db } from '@/lib/db'
import { logMissingSource } from '@/lib/rag/log'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await ctx.params
    if (!id || id.length < 5) {
      logMissingSource({ route: '/api/library/[id]', sourceId: id, reason: 'invalid_id' })
      return NextResponse.json({ error: 'معرف المصدر غير صالح.' }, { status: 400 })
    }
    const source = await db.source.findUnique({ where: { id } })
    if (!source) {
      logMissingSource({ route: '/api/library/[id]', sourceId: id })
      return NextResponse.json({ error: 'المصدر غير موجود.' }, { status: 404 })
    }

    const sampleChunks = await db.chunk.findMany({
      where: { sourceId: id },
      orderBy: { chunkIndex: 'asc' },
      take: 5,
      select: {
        id: true,
        pageNumber: true,
        chapter: true,
        originalText: true,
      },
    })

    const sample = sampleChunks.map((c) => ({
      id: c.id,
      pageNumber: c.pageNumber,
      chapter: c.chapter,
      text: c.originalText.slice(0, 200),
    }))

    return NextResponse.json({
      id: source.id,
      title: source.title,
      author: source.author,
      sourceType: source.sourceType,
      edition: source.edition,
      publisher: source.publisher,
      year: source.year,
      fileName: source.fileName,
      filePath: source.filePath,
      fileSize: source.fileSize,
      pageCount: source.pageCount,
      chunkCount: source.chunkCount,
      status: source.status,
      isTextExtracted: source.isTextExtracted,
      ocrRequired: source.ocrRequired,
      extractionError: source.extractionError,
      trustLevel: source.trustLevel,
      isOfficial: source.isOfficial,
      organization: source.organization,
      allowedUsage: source.allowedUsage,
      language: source.language,
      createdAt: source.createdAt,
      updatedAt: source.updatedAt,
      sample,
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر جلب المصدر.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}

export async function DELETE(
  _req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await ctx.params
    const source = await db.source.findUnique({ where: { id } })
    if (!source) {
      logMissingSource({ route: '/api/library/[id] DELETE', sourceId: id })
      return NextResponse.json({ error: 'المصدر غير موجود.' }, { status: 404 })
    }

    // Cascade deletes chunks (Prisma handles via onDelete: Cascade on Chunk.source)
    await db.source.delete({ where: { id } })

    // Delete the underlying PDF file if it exists and is a real path
    try {
      if (source.filePath && source.filePath !== '—') {
        const p = source.filePath
        if (path.isAbsolute(p)) {
          await fs.access(p)
          await fs.unlink(p)
        }
      }
    } catch {
      // ignore file errors
    }

    return NextResponse.json({ ok: true })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر حذف المصدر.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
