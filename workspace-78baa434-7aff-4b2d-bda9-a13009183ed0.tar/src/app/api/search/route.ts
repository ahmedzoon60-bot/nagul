/**
 * Search API
 * POST /api/search
 * Body: { question, sourceIds, mode?, scopeMode? }
 *
 * Pipeline: classify -> policy -> filter -> hybridSearch -> ragAnswer -> validateClaims
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  classifyQuestion,
  getPolicy,
  filterSourcesByPolicy,
} from '@/lib/rag/policy'
import { hybridSearch, toEvidence } from '@/lib/rag/search'
import { ragAnswer, validateClaims } from '@/lib/rag/llm'
import { logEmptySearch } from '@/lib/rag/log'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 300

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'طلب غير صالح.' }, { status: 400 })
    }

    const question = String(body.question || '').trim()
    let sourceIds: string[] = Array.isArray(body.sourceIds)
      ? body.sourceIds.filter((s: unknown) => typeof s === 'string' && s.length > 0)
      : []
    const mode = (body.mode === 'keyword' || body.mode === 'semantic' || body.mode === 'hybrid'
      ? body.mode
      : 'hybrid') as 'keyword' | 'semantic' | 'hybrid'
    const scopeMode =
      body.scopeMode === 'this_book' ||
      body.scopeMode === 'user_library' ||
      body.scopeMode === 'official'
        ? body.scopeMode
        : 'user_library'

    if (!question || question.length < 2) {
      return NextResponse.json(
        { error: 'اكتب سؤالاً صالحًا.' },
        { status: 400 }
      )
    }
    if (sourceIds.length === 0) {
      return NextResponse.json(
        { error: 'حدد مصدرًا واحدًا على الأقل للبحث.' },
        { status: 400 }
      )
    }

    // 1. Classify question and fetch policy
    const questionType = classifyQuestion(question)
    const policy = getPolicy(questionType)

    // 2. Look up the actual source records for filtering (we need sourceType)
    const sourcesMeta = await db.source.findMany({
      where: { id: { in: sourceIds } },
      select: { id: true, sourceType: true, isOfficial: true, title: true },
    })

    // 3. Filter by policy
    let filtered: Array<{ id: string; sourceType: string; isOfficial?: boolean }> =
      sourcesMeta.map((s) => ({
        id: s.id,
        sourceType: s.sourceType,
        isOfficial: s.isOfficial,
      }))

    let policyWarning: string | null = null
    if (!policy.isPersonalFatwa) {
      const beforeCount = filtered.length
      filtered = filterSourcesByPolicy(filtered, policy)
      // If filtering removed EVERYTHING, fall back to the original list with a
      // warning instead of hard-blocking. The user still gets results, but the
      // answer carries a note that the source type doesn't ideally match the
      // question type. This keeps the Source Policy Engine advisory (not
      // blocking) for non-fatwa questions.
      if (filtered.length === 0 && beforeCount > 0) {
        filtered = sourcesMeta.map((s) => ({
          id: s.id,
          sourceType: s.sourceType,
          isOfficial: s.isOfficial,
        }))
        policyWarning =
          `نوع السؤال المُصنّف: «${questionType}». المصادر المختارة لا تشمل النوع المثالي ` +
          `(${policy.allowedSourceTypes.join('، ')}). تُعرض النتائج من المصادر المتاحة ` +
          `مع تنبيه أن المصدر قد لا يكون الأمثل لهذا السؤال.`
      }
    }

    // Personal fatwa: hard-block (never issue independent fatwa)
    if (policy.isPersonalFatwa) {
      const abstainAnswer = {
        summary:
          'هذا السؤال يتعلق بحالة شخصية، ولا يقدم النظام فتوى مستقلة. يُحال المستخدم إلى جهة مؤهلة.',
        claims: [],
        quotes: [],
        confidence: 'insufficient' as const,
        abstain: true,
        abstain_reason:
          'هذا السؤال يتعلق بحالة شخصية، ولا يقدم النظام فتوى مستقلة.',
        level: policy.contentLevel,
        notes: policy.policyNotes,
      }
      await db.searchQuery.create({
        data: {
          question,
          searchType: mode,
          scopeMode,
          sourceIds: sourceIds.join(','),
          answer: JSON.stringify(abstainAnswer),
          confidence: 'insufficient',
          evidenceCount: 0,
          abstained: true,
          abstainReason: abstainAnswer.abstain_reason,
        },
      })
      return NextResponse.json({
        answer: abstainAnswer,
        evidence: [],
        issues: [],
        policy: {
          questionType,
          contentLevel: policy.contentLevel,
          isPersonalFatwa: true,
          policyNotes: policy.policyNotes,
          allowedSourceTypes: policy.allowedSourceTypes,
        },
      })
    }

    const filteredSourceIds = filtered.map((s) => s.id)

    // 4. Hybrid search
    const scoredChunks = await hybridSearch(question, filteredSourceIds, {
      mode,
      topK: 8,
    })

    // 5. No results -> abstain (but include policyWarning in notes if present)
    if (scoredChunks.length === 0) {
      logEmptySearch({
        route: '/api/search',
        question,
        sourceIds: filteredSourceIds,
        chunkCount: 0,
      })
      const noResultNotes =
        'لم يتم العثور على مقاطع ذات صلة كافية.' +
        (policyWarning ? ' ' + policyWarning : '')
      const abstainAnswer = {
        summary: policyWarning
          ? 'لم أجد مقاطع ذات صلة كافية في المصادر المحددة. قد لا يكون المصدر المختار الأمثل لهذا نوع السؤال.'
          : 'لم أجد في المصادر المحددة ما يكفي للإجابة بثقة. يُنصح بصياغة سؤال آخر أو إضافة مصادر إضافية.',
        claims: [],
        quotes: [],
        confidence: 'insufficient' as const,
        abstain: true,
        abstain_reason: 'لم أجد في المصادر المحددة ما يكفي للإجابة بثقة.',
        level: policy.contentLevel,
        notes: noResultNotes,
      }
      await db.searchQuery.create({
        data: {
          question,
          searchType: mode,
          scopeMode,
          sourceIds: filteredSourceIds.join(','),
          answer: JSON.stringify(abstainAnswer),
          confidence: 'insufficient',
          evidenceCount: 0,
          abstained: true,
          abstainReason: abstainAnswer.abstain_reason,
        },
      })
      return NextResponse.json({
        answer: abstainAnswer,
        evidence: [],
        issues: [],
        policy: {
          questionType,
          contentLevel: policy.contentLevel,
          isPersonalFatwa: policy.isPersonalFatwa,
          policyNotes: policy.policyNotes,
          allowedSourceTypes: policy.allowedSourceTypes,
        },
      })
    }

    // 6. Build evidence + RAG answer
    const evidence = scoredChunks.map(toEvidence)
    const policyContext = `نوع السؤال: ${questionType}\nمستوى المحتوى: ${policy.contentLevel}\nملاحظات السياسة: ${policy.policyNotes}\n${
      policy.isPersonalFatwa
        ? 'تنبيه: هذا سؤال فتوى شخصية - لا تقدم حكمًا مستقلًا، أحِل إلى مختص.'
        : ''
    }${policyWarning ? '\nتنبيه المصادر: ' + policyWarning : ''}`

    const answer = await ragAnswer(question, evidence, policyContext)
    // Attach the policy warning to the answer notes so the UI can display it
    if (policyWarning) {
      answer.notes = (answer.notes ? answer.notes + ' ' : '') + policyWarning
    }
    const issues = validateClaims(answer, evidence)

    // 7. Persist SearchQuery
    try {
      await db.searchQuery.create({
        data: {
          question,
          searchType: mode,
          scopeMode,
          sourceIds: filteredSourceIds.join(','),
          answer: JSON.stringify(answer),
          confidence: answer.confidence,
          evidenceCount: evidence.length,
          abstained: answer.abstain,
          abstainReason: answer.abstain_reason,
        },
      })
    } catch {
      // persistence is best-effort; do not block the response
    }

    return NextResponse.json({
      answer,
      evidence,
      issues,
      policy: {
        questionType,
        contentLevel: policy.contentLevel,
        isPersonalFatwa: policy.isPersonalFatwa,
        policyNotes: policy.policyNotes,
        allowedSourceTypes: policy.allowedSourceTypes,
        policyWarning,
      },
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر إجراء البحث.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
