/**
 * Stats API
 * GET /api/stats
 *
 * Trust panel counts: sources, chunks, searches, citations, verified breakdown.
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const [
      sources,
      userSources,
      officialSources,
      chunks,
      searches,
      citations,
      verifiedMatched,
      verifiedPartial,
    ] = await Promise.all([
      db.source.count(),
      db.source.count({ where: { isOfficial: false } }),
      db.source.count({ where: { isOfficial: true } }),
      db.chunk.count(),
      db.searchQuery.count(),
      db.citation.count(),
      db.citation.count({ where: { status: 'matched' } }),
      db.citation.count({ where: { status: 'partial' } }),
    ])

    return NextResponse.json({
      sources,
      userSources,
      officialSources,
      chunks,
      searches,
      citations,
      verifiedMatched,
      verifiedPartial,
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'تعذّر جلب الإحصائيات.', detail: String(err?.message || err) },
      { status: 500 }
    )
  }
}
