import type { Metadata } from "next";
import { IBM_Plex_Sans_Arabic, Amiri } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "next-themes";
import { Providers } from "@/components/naql/Providers";

const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  variable: "--font-arabic",
  subsets: ["arabic", "latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700"],
  display: "swap",
});

const amiri = Amiri({
  variable: "--font-amiri",
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "نقل محقق — منصة البحث والتحقق في المصادر الشرعية",
  description:
    "منصة بحث وتوثيق ذكية تساعد طلاب العلم والباحثين على الوصول إلى النصوص الشرعية، تحليلها، والتحقق من الاقتباسات مع ربط كل نتيجة بمصدرها وموضعها الأصلي.",
  keywords: [
    "نقل محقق",
    "بحث شرعي",
    "تحقق من الاقتباس",
    "تفسير الطبري",
    "مصادر شرعية",
    "RAG",
    "تحقيق",
    "توثيق",
  ],
  authors: [{ name: "Naql Muhaqqiq" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${ibmPlexArabic.variable} ${amiri.variable} font-arabic antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
          <Providers>{children}</Providers>
        </ThemeProvider>
        <Toaster position="top-center" dir="rtl" />
      </body>
    </html>
  );
}
