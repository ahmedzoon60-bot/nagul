'use client'

import { useEffect } from 'react'
import { useStore } from '@/lib/store'
import { AppShell } from '@/components/naql/AppShell'
import { HomeSection } from '@/components/naql/HomeSection'
import { LibrarySection } from '@/components/naql/LibrarySection'
import { SearchSection } from '@/components/naql/SearchSection'
import { VerifySection } from '@/components/naql/VerifySection'
import { SourceViewer } from '@/components/naql/SourceViewer'
import { AnalysisSection } from '@/components/naql/AnalysisSection'

export default function Home() {
  const section = useStore((s) => s.section)
  const loadLibrary = useStore((s) => s.loadLibrary)
  const loadStats = useStore((s) => s.loadStats)
  const loadUser = useStore((s) => s.loadUser)

  useEffect(() => {
    loadLibrary()
    loadStats()
    loadUser()
  }, [loadLibrary, loadStats, loadUser])

  return (
    <AppShell>
      <div key={section} className="animate-fade-in-up">
        {section === 'home' && <HomeSection />}
        {section === 'library' && <LibrarySection />}
        {section === 'search' && <SearchSection />}
        {section === 'verify' && <VerifySection />}
        {section === 'source' && <SourceViewer />}
        {section === 'analysis' && <AnalysisSection />}
      </div>
    </AppShell>
  )
}
