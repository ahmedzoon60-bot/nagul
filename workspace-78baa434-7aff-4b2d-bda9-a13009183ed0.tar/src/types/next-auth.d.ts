/**
 * Module augmentation for next-auth to add our custom session/token fields.
 */
import 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      id?: string
      email?: string | null
      name?: string | null
      role?: string
    }
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id?: string
    role?: string
  }
}
